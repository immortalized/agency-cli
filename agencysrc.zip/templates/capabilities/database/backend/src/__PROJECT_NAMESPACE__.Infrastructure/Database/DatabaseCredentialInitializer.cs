using Microsoft.Extensions.Hosting;

namespace __PROJECT_NAMESPACE__.Infrastructure.Database;

public sealed class DatabaseCredentialInitializer(
    IDatabaseCredentialProvider credentialProvider,
    DatabaseCredentialState credentialState)
    : IHostedService
{
    public async Task StartAsync(
        CancellationToken cancellationToken)
    {
        var credential =
            await credentialProvider
                .GetCredentialAsync(
                    cancellationToken);

        credentialState.Initialize(credential);
    }

    public Task StopAsync(
        CancellationToken cancellationToken) =>
        Task.CompletedTask;
}
